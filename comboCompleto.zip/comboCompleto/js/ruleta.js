// Código de la ruleta — inicializa una vez y evita duplicidades.
(function () {
  if (window.__ruletaInitialized) return;
  window.__ruletaInitialized = true;

  document.addEventListener('DOMContentLoaded', () => {
    // Configuración
    const wheelNumbers = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
    const redNumbers = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

    // Elementos del DOM (tu HTML ya tiene estos ids)
    const balanceSpan = document.getElementById("balance-value");
    const totalBetSpan = document.getElementById("total-bet");
    const betAmountInput = document.getElementById("bet-amount");
    const resultText = document.getElementById("result-text");
    const messageText = document.getElementById("message-text");
    const lastSpinText = document.getElementById("last-spin");
    const wheelTrack = document.getElementById("wheel-track");
    const wheelNumberSpan = document.getElementById("wheel-number");
    const spinButton = document.getElementById("spin-button");
    const grid = document.getElementById("bet-grid");

    if (!balanceSpan || !grid || !wheelTrack) {
      console.warn('ruleta.js: elementos necesarios no encontrados. Comprueba ruleta.html');
      return;
    }

    // Estado
    let balance = parseInt(balanceSpan.textContent, 10) || 1000;
    let currentBets = []; // {type, value, amount}
    let lastBets = [];

    function updateBalance(diff) {
      balance += diff;
      balanceSpan.textContent = balance;
    }

    function updateTotalBet() {
      const total = currentBets.reduce((s, b) => s + b.amount, 0);
      if (totalBetSpan) totalBetSpan.textContent = total;
    }

    function setStatus(result, msg, isWin = null) {
      if (resultText) resultText.textContent = result;
      if (messageText) messageText.textContent = msg;
      if (resultText) {
        resultText.classList.remove("status-win", "status-lose");
        if (isWin === true) resultText.classList.add("status-win");
        else if (isWin === false) resultText.classList.add("status-lose");
      }
      if (messageText) {
        messageText.classList.remove("status-win", "status-lose");
        if (isWin === true) messageText.classList.add("status-win");
        else if (isWin === false) messageText.classList.add("status-lose");
      }
    }

    function describeBet(type, value) {
      if (type === "number") return `número ${value}`;
      if (type === "color") return value === "red" ? "rojo" : "negro";
      if (type === "parity") return value === "even" ? "par" : "impar";
      if (type === "dozen") {
        if (value === "1") return "1ª docena (1–12)";
        if (value === "2") return "2ª docena (13–24)";
        return "3ª docena (25–36)";
      }
      if (type === "column") return `${value}ª columna`;
      return `${type} ${value}`;
    }

    // Evitar doble attach al grid
    if (!grid.dataset.ruletaInit) {
      grid.dataset.ruletaInit = "1";
      grid.addEventListener("click", (ev) => {
        const cell = ev.target.closest(".cell");
        if (!cell) return;
        const type = cell.dataset.type;
        const value = cell.dataset.value;
        const amount = parseInt(betAmountInput ? betAmountInput.value : '0', 10) || 0;
        if (amount <= 0) {
          setStatus("—", "Introduce un monto de apuesta válido.", false);
          return;
        }
        currentBets.push({
          type,
          value: type === "number" ? parseInt(value, 10) : value,
          amount
        });
        cell.classList.add("selected");
        updateTotalBet();
        setStatus("Apuesta añadida", `Has apostado ${amount} créditos a ${describeBet(type, value)}.`);
      });
    }

    // Botones data-bet / data-action (evitar duplicados)
    const chipButtons = Array.from(document.querySelectorAll(".chip-btn[data-bet]"));
    chipButtons.forEach(btn => {
      if (btn.dataset.ruletaInit) return;
      btn.dataset.ruletaInit = "1";
      btn.addEventListener("click", () => {
        const betType = btn.dataset.bet;
        const betValue = btn.dataset.value;
        const amount = parseInt(betAmountInput ? betAmountInput.value : '0', 10) || 0;
        if (amount <= 0) { setStatus("—", "Introduce un monto de apuesta válido.", false); return; }
        currentBets.push({
          type: betType,
          value: betType === "number" ? parseInt(betValue, 10) : betValue,
          amount
        });
        updateTotalBet();
        setStatus("Apuesta añadida", `Has apostado ${amount} créditos a ${describeBet(betType, betValue)}.`);
      });
    });

    // Acciones (clear, undo, double, rebet)
    function safeQuery(selector) { return document.querySelector(selector); }

    const btnClear = safeQuery('[data-action="clear"]');
    if (btnClear && !btnClear.dataset.ruletaInit) {
      btnClear.dataset.ruletaInit = "1";
      btnClear.addEventListener('click', () => {
        currentBets = [];
        updateTotalBet();
        grid.querySelectorAll(".cell.selected").forEach(c => c.classList.remove("selected"));
        setStatus("—", "Todas las apuestas han sido eliminadas.");
      });
    }

    const btnUndo = safeQuery('[data-action="undo"]');
    if (btnUndo && !btnUndo.dataset.ruletaInit) {
      btnUndo.dataset.ruletaInit = "1";
      btnUndo.addEventListener('click', () => {
        if (currentBets.length === 0) return;
        const last = currentBets.pop();
        updateTotalBet();
        if (last && (last.type === "number" || last.type === "column")) {
          const selector = `.cell[data-type="${last.type}"][data-value="${last.value}"]`;
          const cell = document.querySelector(selector);
          if (cell) cell.classList.remove("selected");
        }
        setStatus("—", "Última apuesta deshecha.");
      });
    }

    const btnDouble = safeQuery('[data-action="double"]');
    if (btnDouble && !btnDouble.dataset.ruletaInit) {
      btnDouble.dataset.ruletaInit = "1";
      btnDouble.addEventListener('click', () => {
        if (currentBets.length === 0) return;
        const currentTotal = currentBets.reduce((s,b) => s + b.amount, 0);
        if (balance < currentTotal) { setStatus("—", "No tienes saldo suficiente para doblar.", false); return; }
        currentBets = currentBets.map(b => ({...b, amount: b.amount * 2}));
        updateTotalBet();
        setStatus("—", "Has doblado el valor de tus apuestas.");
      });
    }

    const btnRebet = document.getElementById("btn-rebet");
    if (btnRebet && !btnRebet.dataset.ruletaInit) {
      btnRebet.dataset.ruletaInit = "1";
      btnRebet.addEventListener("click", () => {
        if (!lastBets.length) { setStatus("—", "Todavía no hay apuestas anteriores para repetir."); return; }
        const totalLast = lastBets.reduce((s,b) => s + b.amount, 0);
        if (balance < totalLast) { setStatus("—", "No tienes saldo suficiente para reapostar todo.", false); return; }
        currentBets = JSON.parse(JSON.stringify(lastBets));
        updateTotalBet();
        setStatus("—", "Apuestas anteriores reaplicadas.");
      });
    }

    // Evaluación de apuestas (mismo comportamiento que antes)
    function evaluateBet(bet, number) {
      if (bet.type === "number") return number === bet.value ? bet.amount * 36 : 0;
      if (bet.type === "color") {
        if (number === 0) return 0; const isRed = redNumbers.has(number);
        return ((bet.value === "red" && isRed) || (bet.value === "black" && !isRed)) ? bet.amount * 2 : 0;
      }
      if (bet.type === "parity") {
        if (number === 0) return 0; const isEven = number % 2 === 0;
        return ((bet.value === "even" && isEven) || (bet.value === "odd" && !isEven)) ? bet.amount * 2 : 0;
      }
      if (bet.type === "dozen") {
        if (number === 0) return 0;
        if (bet.value === "1" && number >= 1 && number <= 12) return bet.amount * 3;
        if (bet.value === "2" && number >= 13 && number <= 24) return bet.amount * 3;
        if (bet.value === "3" && number >= 25 && number <= 36) return bet.amount * 3;
        return 0;
      }
      if (bet.type === "column") {
        if (number === 0) return 0;
        const col1 = [1,4,7,10,13,16,19,22,25,28,31,34];
        const col2 = [2,5,8,11,14,17,20,23,26,29,32,35];
        const col3 = [3,6,9,12,15,18,21,24,27,30,33,36];
        const colSet = bet.value === "1" ? col1 : bet.value === "2" ? col2 : col3;
        return colSet.includes(number) ? bet.amount * 3 : 0;
      }
      if (bet.type === "range") {
        if (number === 0) return 0;
        if (bet.value === "low" && number >= 1 && number <= 18) return bet.amount * 2;
        if (bet.value === "high" && number >= 19 && number <= 36) return bet.amount * 2;
        return 0;
      }
      return 0;
    }

    // Giro (un solo listener, evita duplicidad)
    function spinWheel() {
      const totalBet = currentBets.reduce((s, b) => s + b.amount, 0);
      if (totalBet <= 0) { setStatus("—", "Primero coloca tus apuestas.", false); return; }
      if (balance < totalBet) { setStatus("—", "No tienes saldo suficiente para esta jugada.", false); return; }

      updateBalance(-totalBet);
      setStatus("Girando...", "La ruleta está en marcha, suerte.");
      if (spinButton) spinButton.disabled = true;

      // animación CSS: usamos transition approach para evitar acumulación de transform
      wheelTrack.style.transition = 'none';
      void wheelTrack.offsetWidth;

      const winningIndex = Math.floor(Math.random() * wheelNumbers.length);
      const winningNumber = wheelNumbers[winningIndex];
      // calcular ángulo para centrar sector (opcional)
      const sectors = wheelNumbers.length;
      const degPer = 360 / sectors;
      const sectorCenter = (winningIndex * degPer) + degPer / 2;
      const targetAngle = 360 - sectorCenter;
      const extraSpins = 6 + Math.floor(Math.random() * 3);
      const finalAngle = extraSpins * 360 + targetAngle;
      const duration = 4 + Math.random() * 1.2;

      requestAnimationFrame(() => {
        wheelTrack.style.transition = `transform ${duration}s cubic-bezier(.18,.86,.18,1)`;
        wheelTrack.style.transform = `rotate(${finalAngle}deg)`;
      });

      wheelTrack.addEventListener('transitionend', function handler() {
        wheelTrack.removeEventListener('transitionend', handler);
        wheelTrack.style.transition = 'none';
        const normalized = finalAngle % 360;
        wheelTrack.style.transform = `rotate(${normalized}deg)`;
        setTimeout(() => {
          if (spinButton) spinButton.disabled = false;
          // calcular resultado y pagos
          const isRed = redNumbers.has(winningNumber);
          const color = winningNumber === 0 ? "verde" : (isRed ? "rojo" : "negro");
          lastSpinText.textContent = `Último giro: ${winningNumber} (${color})`;
          if (wheelNumberSpan) wheelNumberSpan.textContent = String(winningNumber);

          let payout = 0;
          currentBets.forEach(bet => { payout += evaluateBet(bet, winningNumber); });

          if (payout > 0) {
            updateBalance(payout);
            const profit = payout - totalBet;
            setStatus(`¡Ganaste! Número: ${winningNumber} (${color})`, `Cobras ${payout} créditos. Beneficio neto: +${profit}.`, true);
          } else {
            setStatus(`Perdiste. Número: ${winningNumber} (${color})`, `Has perdido ${totalBet} créditos en esta tirada.`, false);
          }

          lastBets = JSON.parse(JSON.stringify(currentBets));
          currentBets = [];
          updateTotalBet();
          grid.querySelectorAll(".cell.selected").forEach(c => c.classList.remove("selected"));
          // limpiar transform para futuros giros (sólo visual)
          wheelTrack.style.transition = '';
        }, 20);
      }, { once: true });
    }

    // conectar botón girar (evitar múltiples listeners)
    const spinSelectors = [];
    if (spinButton) spinSelectors.push(spinButton);
    document.querySelectorAll('[data-action="spin"]').forEach(b => spinSelectors.push(b));
    spinSelectors.forEach(btn => {
      if (btn.dataset.ruletaInit) return;
      btn.dataset.ruletaInit = "1";
      btn.addEventListener('click', spinWheel);
    });

    // inicializar UI
    updateBalance(0); updateTotalBet(); setStatus("—", "Coloca tus fichas y gira.");
    // exponer API para debugging
    window.ruletaApp = { getBalance: () => balance, getBets: () => currentBets.slice(), spin: spinWheel };
  });
})();

